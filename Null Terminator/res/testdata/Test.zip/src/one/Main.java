package one;

class Target {

	public Target(){}

	public void doAction_Vart_Line11() {
		System.out.println(this);
	}
	
	public Object getNull()
	{
		return null;
	}
	
	public Target getSelf()
	{
		return this;
	}
	
}

class Client {

	public Target t5;
	public Target t6;
	public Target t7;
	public Target t8 = new Target();
	public Target t10;
	
	public Client() {
		t6 = new Target();
		t7 = null;
	}
	
	public Target get() {
		return null;
	}
	
	public void unSet(char x) {
		t8 = null;
	}
	
	public void unSet() {
		t8 = null;
	}
	
	public void unSet(int x) {
		
	}
	
	public Target getTarget()
	{
		return t7;
	}
	
	public void client(Target uselessArg, Target t1) {
		Target t2 = t1;
		Target t3 = get();
		Target t4 = null;
		Target t5 = getTarget();
		t5 = null;
		Target t6 = (Target) getTarget().getNull();
		
		Target t;
		t = null;
		
		if (t5 != null)
			System.out.println("local");
		
		if(t1 != null) {
			System.out.println("param");
		}
		
		if (t8 != null)
			System.out.println("field");
		
		if (t10 != null)
			System.out.println("uninitialized");
		
	}
	
}


public class Main {

	public static void main(String argv[]) {
		Client c = new Client();
		c.client(new Target(),null);
	}
	
	public void createClient()
	{
		Target t = null;
		Target q = null;
		int x=4;
		if (x>0)
			t = new Target();
		String s =new String("S");
		new Client().client(q,t);
	}
	
}