package myPackage;

public abstract class Client {

	private Target target;
	
	public abstract Target init();
	
	public Target init(float f)
	{
		return null;
	}
	
	public void aMethod()
	{
		target = init();
		int i=0;
		if (target != null)
			{
			System.out.println("target is not null");
			i++;
			}
	}
}
