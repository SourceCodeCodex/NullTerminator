package myPackage;

public class Main {

	public static void main(String[] args) 
	{
		Client c = new SubClient();
		Target target = c.init();
		if (target != null)
			System.out.println("No null");
	}

}
