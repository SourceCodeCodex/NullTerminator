package myPackage;

public class SubClient extends Client
{
	@Override
	public Target init()
	{
		Target t = null;
		int a = 2;
		int b = 3;
		int sum = a+b;
		if (sum % 2 == 0)
			t = new Target();
		return t;
	}
	
	public Target init(int x)
	{
		return new Target();
		
	}
	
	public Target init (char c)
	{
		return null;
	}
}
