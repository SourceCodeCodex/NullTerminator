package myPackage;

public class Target {

	public Target(){}

}
