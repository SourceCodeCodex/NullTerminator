package pepi1;

import java.util.ArrayList;
import java.util.List;

abstract class Root {
	
	protected A parent;	

	protected List<A> children = new ArrayList<A>();

	public void remove(A a) {
		boolean f = children.remove(a);
		if(f) {
			a.parent = null;
			return;
		}
		if(parent != null) {
			parent.remove(a);
		}
	}

}

public class A extends Root {

	public void add(A a) {
		children.add(a);
		a.parent = this;
	}

	public void simpleRemove(A a) {
		children.remove(a);
		a.parent = null;
	}

}

class Main {

}
