package pepi2;

import java.util.ArrayList;
import java.util.List;

public class A {

	protected A parent;	

	protected List<A> children = new ArrayList<A>();

	public void remove(A a) {
		boolean f = children.remove(a);
		if(f) {
			a.parent = null;
			return;
		}
		if(parent != null) {
			parent.remove(a);
		}
	}

	public void add(A a) {
		children.add(a);
		a.parent = this;
	}

	public void simpleRemove(A a) {
		children.remove(a);
		a.parent = null;
	}

}